<?php $__env->startSection('isi3'); ?>
    <section class="content">
      <div class="callout callout-info">
          <h4>Halo :)</h4>

          <p>Silahkan isi form dibawah untuk menambah layanan dihalaman homecare.</p>
        </div>
      <div class="row">
        <!-- left column -->
        <div class="col-md-6 col-md-offset-3" >
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Layanan Homecare</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="<?php echo e(route('formlayanan.store')); ?>" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputPassword1">Nama Homecare</label>
                  <input type="string" name="nama_homecare" class="form-control" id="exampleInputPassword1" placeholder="Nama Homecare">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Jenis Layanan</label>
                  <select class="form-control" name="jenis_layanan">
                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option><?php echo e($data->nama_perawatan); ?></option>
                    <!-- <option>Fisioterapi</option>
                    <option>Perawatan Stoma</option>
                    <option>Perawatan Bayi</option>
                    <option>Perawatan Luka</option>
                    <option>Hipnoterapi</option> -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="exampleInputFile">Foto Homecare</label>
                  <input type="file" id="exampleInputFile" name="foto">

                  <p class="help-block">Maksimal file 1 MB</p>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Alamat Homecare</label>
                  <textarea class="form-control" name="alamat_homecare" rows="3" placeholder="Alamat Homecare"></textarea>
                </div>
              </div>
              <!-- /.box-body --> 
              <div class="box-footer"> 
                <div class="col-md-6 col-md-offset-10">
                  <button type="submit" class="btn btn-primary">Selesai</button>  
                </div>
              </div>
            </a>  
            </form>
          </div>
          <!-- /.box -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanperawat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>