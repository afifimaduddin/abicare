<?php $__env->startSection('isi2'); ?>

<?php if(session()->has('error')): ?>
<script>
  $().ready(function (e) {
    swal({
      title: "Maaf!",
      text: "Jadwal Homecare Tidak Tersedia",
      icon: "warning",
      button: false,
      timer: 2000
    });
  });
</script>
<?php endif; ?>

<script>
  $(function () {

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true,
      dateFormat: "yy-mm-dd",
      minDate: -3
    })


    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })

</script>

<section class="content">
  <div>
    <h4>Pesan Homecare</h4>
  </div>

  <?php if(count($errors) > 0): ?>
  <div class="callout callout-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>  

  <div class="row">
    <!-- left column -->
    <div class="col-md-6">
      <div class="box box-success">
        <div class="box-header">
          <h3 class="box-title">Silahkan Pesan Sesuai Jadwal Homecare</h3>
        </div>

        <form role="form" action="<?php echo e(route('formpesan.store')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <!-- Date -->
            <?php $__currentLoopData = $homecare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="widget-user-username"><?php echo e($data->nama_homecare); ?></h3>
            <input type="hidden" name="id_homecare" value="<?php echo e($data->id_homecare); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
              <label>Tanggal Pemesanan:</label>

              <div class="input-group date">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input min="<?php echo date('Y-m-d') ?>" type="text" name="tanggal_pemesanan" class="form-control pull-right" id="datepicker">
              </div>
              <!-- /.input group -->
            </div>
            <!-- /.form group -->

            <!-- Date range -->
            <!-- <div class="bootstrap-timepicker"> -->
              <div class="form-group">
                <label>Jam Pemesanan:</label>

                <div class="input-group">
                  <input name="jam_pemesanan" type="time" class="form-control timepicker" id="jadwal">
                  <div class="input-group-addon">
                    <i class="fa fa-clock-o"></i>
                  </div>
                </div>
                <a style="color : red">Contoh : 09:00:AM</a>
                <!-- /.input group -->
              </div>
              <!-- /.form group -->
            <!-- </div> -->

            <div class="form-group">
              <label for="exampleInputPassword1">Keluhan pasien:</label>
              <textarea class="form-control" name="keluhan" rows="3" placeholder="Apa keluhan yang anda alamai?"></textarea>
            </div>

            <div class="box-footer">
              <!-- <a href="<?php echo e(url('/riwayatpemesanan')); ?>"> -->
                <div class="col-md-6 col-md-offset-10">
                  <button type="submit" class="btn btn-primary">Pesan</button>
                </div>
                <!-- </a> -->  
              </div>
              <!-- /.form group -->

            </div>
          </form>  
          <!-- /.box-body -->
        </div>
      </div>

      
      <div class="col-md-6">
        <div class="box box-success">
          <div class="box-header">
            <h3 class="box-title">Jadwal Homecare</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Hari Praktek</th>
                  <th>Jam Buka</th>
                  <th>Jam Tutup</th>
                </tr>
              </thead>
              <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($data->hari_praktek); ?></td>
                <td><?php echo e($data->start); ?></td>
                <td><?php echo e($data->end); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <!-- /.box-body -->
          </div>
          <!-- /.row -->
        </section>
        <script>
          $('#jadwal').change(function() {
           $('#jadwal_time').val($('#jadwal').val());
         });
          $(function () {
            $('#example1').DataTable()
            $('#example2').DataTable({
              'paging'      : true,
              'lengthChange': false,
              'searching'   : false,
              'ordering'    : true,
              'info'        : true,
              'autoWidth'   : false
            })
          })
        </script>


        <?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanpasien', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>