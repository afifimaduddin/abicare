<?php $__env->startSection('isi'); ?>

<section class="content-header">
  <h1>
   
    <small></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>
    <li class="active">Daftar Pemesanan</li>
  </ol>
</section>
<section class="content">
  <div class="box">
    <div class="box-header">
      <h3 class="box-title">Daftar Pemesanan</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Nama Homecare</th>
            <th>Nama Perawat</th>
            <th>Nama Pasien</th>
            <th>Tanggal Pemesanan</th>
            <th>Jam Pemesanan</th>
            <th>Keluhan</th>
            <th>Status Pemesanan</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($data->nama_homecare); ?></td>
            <td><a href="<?php echo e(url('admin_pemesanan_perawat')); ?>/<?php echo e($data->id_homecare); ?>" class="btn btn-primary">Lihat Perawat</a></td>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->tanggal_pemesanan); ?></td>
            <td><?php echo e($data->jam_pemesanan); ?></td>
            <td><?php echo e($data->keluhan); ?></td>
            <td>
              <?php if($data->status=='proses'): ?>
                <span class="btn btn-sm btn-info" style="background: #FF0000; border-color: #fff">Proses</span>
                <?php elseif($data->status=='diterima'): ?>
                <span class="btn btn-sm btn-info" style="background: #FFD700; border-color: #fff">Pesanan Diterima</span>
                <?php else: ?>
                <span class="btn btn-sm btn-info" style="background: #32CD32; border-color: #fff">Selesai</span>
                <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.box -->
<!-- /.row -->
</section>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>