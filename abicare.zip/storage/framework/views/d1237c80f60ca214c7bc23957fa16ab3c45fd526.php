<?php $__env->startSection('isi'); ?>

<section class="content-header">
  <h1>

    <small></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>
    <li class="active">Daftar Pengguna</li>
  </ol>
</section>
<section class="content">
  <div class="box">
    <div class="box-header">
      <h3 class="box-title">Daftar Pengguna</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
       <div class="callout callout-success">
    <h4>Verifikasi Akun</h4>

    <p>Pastikan setelah verifikasi akun mengirimkan pemberitahuan melalui email user terkait </p>
  </div>
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Nama Pengguna</th>
            <th>Tangal lahir</th>
            <th>Jenis Kelamin</th>
            <th>E-Mail</th>
            <th>No telefon</th>
            <th>Roles</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $daftarpengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->tanggal_lahir); ?></td>
            <td>
              <?php if($data->jenis_kelamin=='male'): ?>
              <?php echo 'Laki-laki' ?> 
              <?php else: ?>
              <?php echo 'Perempuan' ?>
              <?php endif; ?>
            </td>
            <td><?php echo e($data->email); ?></td>
            <td>+62<?php echo e($data->no_telfon); ?></td>
            <td>
              <?php if($data->id_roles=='1'): ?>
              <?php echo 'Pasien' ?> 
              <?php else: ?>
              <?php echo 'Perawat' ?>
              <?php endif; ?>
            </td>
            <td>
              <?php if($data->status_users=='nonaktif'): ?>
                <a href="<?php echo e(url('/ubahstatususers')); ?>/<?php echo e($data->id); ?>" class="btn btn-sm btn-info" style="background: #FF0000; border-color: #fff">Nonaktif</a>
                <?php else: ?>
                <span class="btn btn-sm btn-info" style="background: #32CD32; border-color: #fff">Aktif</span>
                <a class="btn btn-sm btn-info" style="background: #1E90FF; border-color: #fff" href="https://gmail.com" target="_blank">kirim Pemberitahuan</a>
                <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.box -->
<!-- /.row -->
</section>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>