<?php $__env->startSection('isi2'); ?>
<section class="content-header">
  <h1>
    Pilih Layanan
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Pasien</a></li>
    <li class="active">Pilih Layanan</li>
  </ol>
</section>
<section class="content">
  <div class="callout callout-success">
    <p>Silahkan pilih jenis layanan yang anda butuhkan</p>
  </div>
  
  <section>
    <div class="row">
    <?php $__currentLoopData = $roles_jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
      <div class="box box-widget widget-user-2">
        <div class="widget-user-header bg-white">
        <div class="box-body box-profile">
          <div class="widget-user-image">
            <img class="img-circle" src="<?php echo e(url('asset/dist/img/layanan.png')); ?>" alt="User profile picture">
          </div>
          <h3 class="profile-username text-center">
            <?php echo e($data->nama_perawatan); ?>

          </h3>
          <p class="text-muted text-center">
            <?php echo e($data->id_roles_jenis); ?>

          </p>
        </div>
        <div class="box-footer">
          <a href="<?php echo e(url('/daftarhomecare')); ?>/<?php echo e($data->id_roles_jenis); ?>">
            <center><button type="submit" class="btn btn-primary">Pilih</button></center>
          </a> 
        </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>
  <?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanpasien', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>