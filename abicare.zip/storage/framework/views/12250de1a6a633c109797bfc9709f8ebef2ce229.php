<?php $__env->startSection('isi'); ?>

<section class="content-header">
  <h1>
   
    <small></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>
    <li class="active">Daftar Perawat</li>
  </ol>
</section>
<section class="content">
  <div class="box">
    <div class="box-header">
      <h3 class="box-title">Daftar Perawat</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <table id="example1" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Foto Perawat</th>
            <th>Nama Perawat</th>
            <th>Jenis Kelamin</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $tambahperawat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><img class="profile-user-img img-responsive img-circle" src="<?php echo e(url('storage/asset/dist/img/')); ?>/<?php echo e($data->foto_perawat); ?>" alt="User Avatar" onerror="this.src='<?php echo e(url('asset/dist/img/avatar.png')); ?>'" alt="User profile picture"></td>
            <td><?php echo e($data->nama_perawat); ?></td>
            <td><?php echo e($data->jenis_kelamin); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.box -->
<!-- /.row -->
</section>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>