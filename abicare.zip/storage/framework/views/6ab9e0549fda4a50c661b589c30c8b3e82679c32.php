<p>Click link below to verify your email address:</p>
<p><?php echo e($link); ?></p>
<p>Thank you.</p>