<?php $__env->startSection('isi2'); ?>
<section class="content-header">
  <h1>

    <small></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Pilih Layanan</a></li>
    <li class="active">Daftar Homecare</li>
  </ol>
</section>
<section class="content">
 <!--  -->
  <p></p>
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-success">
        <div class="box-header">
          <h3 class="box-title">Daftar Homecare</h3>
        <!-- /.box-header -->
        <div class="box-body table-responsive no-padding">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>No</th>
              <th>Foto</th>
              <th>Nama Homecare</th>
              <th>Alamat Homecare</th>
              <th>Aksi</th>
            </tr>
          </thead>
            <?php $__currentLoopData = $homecare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($data->id_homecare); ?></td>
              <td><img class="profile-user-img img-responsive img-circle" src="<?php echo e(url('storage/asset/dist/img/')); ?>/<?php echo e($data->foto_homecare); ?>" alt="User Avatar" onerror="this.src='<?php echo e(url('asset/dist/img/avatar.png')); ?>'" alt="User profile picture"></td>
              <td><?php echo e($data->nama_homecare); ?></td>
              <td><?php echo e($data->alamat_homecare); ?></td>
              <td>
                <a href="<?php echo e(url ('/lihatdetail/')); ?>/<?php echo e($data->id_homecare); ?>" class="btn btn-primary" >Lihat detail</a></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.row -->
  </section>
  <script>

  <script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
  <?php $__env->appendSection(); ?>
    <!-- /.content -->
<?php echo $__env->make('halamanpasien', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>