<?php $__env->startSection('content'); ?>
<body class="hold-transition login-page">
    <div class="login-box">
  <div class="login-logo">
     <center><a href="<?php echo e(url('/')); ?>"><img style="max-width:80%;" src="<?php echo e(url('asset/dist/img/abicarelogo.png')); ?>" class="img-responsive"></a></center>
 </div>

    <div class="login-box-body" style="border-radius: 25px">
            <p class="login-box-msg">Login Abicare</p>
              <center><small class="login-box-msg text-muted"><i>*Cek E-mail dan pastikan akun telah terverifikasi</i></small></center>
        <div class="row">
            <div class="panel-body">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                       <!--  <label for="email" class="col-md-2 control-label">E-Mail </label> -->

                        <div class="col-md-12">
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="E-Mail">

                            <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                       <!--  <label for="password" class="col-md-2 control-label">Sandi</label>
 -->
                        <div class="col-md-12">
                            <input id="password" type="password" class="form-control" name="password" required autofocus placeholder="Kata Sandi">

                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                        <!-- <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Login Sebagai</label>
                            <div class="col-md-6">
                                <select name="id_roles" class="form-control">
                                    <?php $__currentLoopData = \App\roles::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($users->id_roles); ?>"><?php echo e($users->nama_roles); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div> -->

                       <!--  <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div> -->

                        <center>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                                <button type="submit" class="btn btn-success pull-center">
                                    Login
                                </button>
                        </center>
                               <!--  <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a> -->
                            </div>
                        </div>
                        <p style="text-align: center;">Belum memiliki akun? Silahkan <a href="<?php echo e(route('register')); ?>"> Daftar</a> disini</p> 
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>