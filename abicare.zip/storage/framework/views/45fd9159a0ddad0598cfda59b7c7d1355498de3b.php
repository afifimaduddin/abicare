<?php $__env->startSection('isi2'); ?>
<section class="content">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <!-- Widget: user widget style 1 -->
      <div class="box box-widget widget-user-2">
        <!-- Add the bg color to the header using any of the bg-* classes -->
        <?php $__currentLoopData = $homecare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="widget-user-header bg-default">
          <div class="widget-user-image">
            <img class="profile-user-img img-responsive img-circle" src="<?php echo e(url('storage/asset/dist/img/')); ?>/<?php echo e($data->foto_homecare); ?>" alt="User Avatar" onerror="this.src='<?php echo e(url('asset/dist/img/avatar.png')); ?>'" alt="User profile picture">
          </div>
          <!-- /.widget-user-image -->
          
          <h3 class="widget-user-username"><?php echo e($data->nama_homecare); ?></h3>
          <h5 class="widget-user-desc"><?php echo e($data->alamat_homecare); ?></h5>
          <h5 class="widget-user-desc" value=""></h5>
        </div>
        <div class="widget-user-image">
        </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <?php $__currentLoopData = $homecare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Profile Image -->
      <div class="box box-success">
        <div class="box-body box-profile">
          <ul class="list-group list-group-unbordered">
            <strong><i class="fa fa-book margin-r-5"></i>Deskripsi Homecare</strong>

            <p class="text-muted"><?php echo e($data->deskripsi_homecare); ?></p>

            <hr>

            <strong><i class="fa fa-envelope-square margin-r-5"></i>E-mail</strong>

            <p class="text-muted"><?php echo e($data->email_homecare); ?></p>

            <hr>

            <strong><i class="fa fa-phone margin-r-5"></i>No Telepon</strong>

            <p class="text-muted"><?php echo e($data->no_telfon); ?></p>

            <hr>

            <strong><i class="fa  fa-money margin-r-5"></i>Tarif</strong>

            <p>
              <?php echo e($data->tarif); ?>

            </p>
          </ul>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>

    <div class="col-md-6">
      <div class="box box-success">
        <div class="box-header">
          <h3 class="box-title">Jadwal Homecare</h3>
        </div>
        <!-- /.box-header -->
        
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Hari Praktek</th>
              <th>Jam Buka</th>
              <th>Jam Tutup</th>
            </tr>
          </thead>
            <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($data->hari_praktek); ?></td>
              <td><?php echo e($data->start); ?></td>
              <td><?php echo e($data->end); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          <!-- /.box-body -->
        </div>
        
        <!-- /.box-body -->
      </div>
      <?php $__currentLoopData = $homecare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(url ('/formpesan/')); ?>/<?php echo e($data->id_homecare); ?>"> 
        <button type="" class="pull-right btn-lg btn-danger" id="">Pesan Homecare
          <i class="fa fa-arrow-circle-right"></i></button>
        </a>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </section>

      <?php $__env->appendSection(); ?>
<?php echo $__env->make('halamanpasien', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>